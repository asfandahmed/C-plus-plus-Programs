#include "TikTacToe.cpp"
int main()
{
 system("TITLE, TIC TAC TOE");
   
 choices();
 getch();
 return 0;   
}
